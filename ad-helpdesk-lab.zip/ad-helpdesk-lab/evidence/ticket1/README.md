Screenshots for Ticket #1 go here — naming: ticket1-0X-description.png
