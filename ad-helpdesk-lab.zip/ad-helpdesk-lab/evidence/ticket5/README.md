Screenshots for Ticket #5 go here — naming: ticket5-0X-description.png
