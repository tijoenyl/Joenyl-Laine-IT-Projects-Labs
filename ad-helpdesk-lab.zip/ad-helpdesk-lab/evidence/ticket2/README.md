Screenshots for Ticket #2 go here — naming: ticket2-0X-description.png
