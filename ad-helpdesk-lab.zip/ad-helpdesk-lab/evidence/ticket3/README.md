Screenshots for Ticket #3 go here — naming: ticket3-0X-description.png
