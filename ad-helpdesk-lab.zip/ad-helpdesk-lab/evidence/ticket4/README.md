Screenshots for Ticket #4 go here — naming: ticket4-0X-description.png
