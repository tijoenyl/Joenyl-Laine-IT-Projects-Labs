Screenshots for Ticket #6 go here — naming: ticket6-0X-description.png
