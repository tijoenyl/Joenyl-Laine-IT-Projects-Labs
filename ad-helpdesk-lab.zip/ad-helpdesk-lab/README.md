# Active Directory Helpdesk Simulation Lab

A hands-on Tier 1 helpdesk simulation built in VirtualBox. Six real-world support tickets — identity, policy, and network issues — troubleshot live on a Windows Server 2022 domain, each documented with root cause, resolution, and screenshot evidence captured during the fix.

## Lab Environment

| Component | Details |
|---|---|
| Domain | `lainecorp.local` (NetBIOS: LAINECORP) |
| Domain Controller | DC01 — Windows Server 2022, static IP 192.168.10.10, AD DS + DNS |
| Client | Euser01 — domain-joined workstation, static IP on internal network |
| Test User | Kyle Lowry (`klowry`) |
| Hypervisor | VirtualBox (Internal Network: LabNetwork) |

## Tickets

| # | Ticket | Category |
|---|---|---|
| 1 | [Account Lockout](tickets/ticket1-account-lockout.md) | Identity |
| 2 | [Password Reset](tickets/ticket2-password-reset.md) | Identity |
| 3 | [Missing Group Membership / Access Denied](tickets/ticket3-group-membership-access-denied.md) | Identity / Permissions |
| 4 | [Disabled Account](tickets/ticket4-disabled-account.md) | Identity |
| 5 | [GPP Mapped Drive Not Applying](tickets/ticket5-gpp-drive-map.md) | Group Policy |
| 6 | [DNS Misconfiguration](tickets/ticket6-dns-misconfig.md) | Network |

Each ticket follows a consistent structure: **Symptoms → Tools Used → Root Cause → Resolution → Security Note → Prevention → Evidence.**

## Skills Demonstrated

- Active Directory Users and Computers (account management, group membership, unlock/enable/reset workflows)
- Group Policy Management (GPP drive maps, item-level targeting, `gpupdate` / `gpresult`)
- Windows networking troubleshooting (DNS client configuration, `ipconfig`, `nslookup`, connectivity testing)
- Kerberos authentication behavior (token refresh, group evaluation at logon)
- Ticket documentation and evidence capture to professional helpdesk standards

## Repo Structure

```
ad-helpdesk-lab/
├── README.md
├── tickets/          # One markdown write-up per ticket
├── evidence/         # Screenshots, organized per ticket
│   ├── ticket1/
│   ├── ...
│   └── ticket6/
└── scripts/          # Screenshot organizer + publish helper
```
